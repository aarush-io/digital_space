// src/config/siteConfig.js
// ============================================================
// SINGLE SOURCE OF TRUTH — edit everything here
// ============================================================

const siteConfig = {
  // ── Identity ────────────────────────────────────────────
  name: "Alex Rivera",
  handle: "@alexrivera",
  bio: "Building things that matter. Obsessed with clean code & broken synthesizers.",
  location: "San Francisco, CA",
  profileImage: "https://api.dicebear.com/7.x/avataaars/svg?seed=alexrivera&backgroundColor=b6e3f4",
  badges: ["Student", "Builder", "Music", "Open Source", "Coffee"],

  // ── APIs ─────────────────────────────────────────────────
  discordId: "794644730064576522",   // Replace with your Discord user ID
  githubUsername: "torvalds",        // Replace with your GitHub username

  // ── Social Links ─────────────────────────────────────────
  socials: [
    {
      id: "github",
      label: "GitHub",
      href: "https://github.com/torvalds",
      color: "#e2e8f0",
    },
    {
      id: "twitter",
      label: "Twitter / X",
      href: "https://x.com/",
      color: "#60a5fa",
    },
    {
      id: "instagram",
      label: "Instagram",
      href: "https://instagram.com/",
      color: "#f472b6",
    },
    {
      id: "discord",
      label: "Discord",
      href: "https://discord.com/",
      color: "#818cf8",
    },
    {
      id: "email",
      label: "Email",
      href: "mailto:alex@example.com",
      color: "#34d399",
    },
  ],

  // ── About Me ─────────────────────────────────────────────
  about: {
    whoAmI:
      "I'm a 20-year-old computer science student and indie maker. I love exploring the intersection of design, code, and music.",
    building:
      "A minimal SaaS tool for tracking personal reading habits with beautiful data visualizations.",
    learning:
      "Systems programming in Rust, advanced DSP concepts, and the art of making things people actually use.",
    techStack: [
      "React",
      "TypeScript",
      "Rust",
      "Node.js",
      "PostgreSQL",
      "Figma",
      "Linux",
      "WebAudio API",
    ],
  },

  // ── Currently ─────────────────────────────────────────────
  currently: {
    building: "ReadStack — personal reading tracker",
    studying: "Rust & Operating Systems (CS 162)",
    listening: "Floating Points, Jon Hopkins, Bicep",
  },

  // ── Music Playlist ────────────────────────────────────────
  // Add local audio files in /public/audio/ and reference them here
  // e.g. src: "/audio/track1.mp3"
  playlist: [
    {
      id: 1,
      title: "LesAlpx",
      artist: "Floating Points",
      cover: "https://picsum.photos/seed/fp1/200/200",
      src: "",   // "/audio/track1.mp3"
    },
    {
      id: 2,
      title: "Emerald Rush",
      artist: "Jon Hopkins",
      cover: "https://picsum.photos/seed/jh2/200/200",
      src: "",
    },
    {
      id: 3,
      title: "Glue",
      artist: "Bicep",
      cover: "https://picsum.photos/seed/bc3/200/200",
      src: "",
    },
    {
      id: 4,
      title: "Sundial",
      artist: "Mall Grab",
      cover: "https://picsum.photos/seed/mg4/200/200",
      src: "",
    },
    {
      id: 5,
      title: "Age of",
      artist: "FKA Twigs",
      cover: "https://picsum.photos/seed/fk5/200/200",
      src: "",
    },
    {
      id: 6,
      title: "Lavender",
      artist: "The Blaze",
      cover: "https://picsum.photos/seed/tb6/200/200",
      src: "",
    },
    {
      id: 7,
      title: "Carbon",
      artist: "Bonobo",
      cover: "https://picsum.photos/seed/bn7/200/200",
      src: "",
    },
    {
      id: 8,
      title: "Before the Dawn",
      artist: "Caribou",
      cover: "https://picsum.photos/seed/cb8/200/200",
      src: "",
    },
    {
      id: 9,
      title: "Circles",
      artist: "Four Tet",
      cover: "https://picsum.photos/seed/ft9/200/200",
      src: "",
    },
    {
      id: 10,
      title: "Teardrop",
      artist: "Massive Attack",
      cover: "https://picsum.photos/seed/ma10/200/200",
      src: "",
    },
  ],
};

export default siteConfig;
